tinyMCE.addI18n('en.asciimath',{
	desc : 'Ajouter une formule'
});

tinyMCE.addI18n('en.asciimathcharmap',{
	desc : 'Symboles math�matiques'
});
