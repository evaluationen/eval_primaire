tinyMCE.addI18n('en.asciimath',{
	desc : 'Add New Math'
});

tinyMCE.addI18n('en.asciimathcharmap',{
	desc : 'Math Symbols'
});
