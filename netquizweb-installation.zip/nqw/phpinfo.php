<?php

// Affiche toutes les informations, comme le ferait INFO_ALL
phpinfo(INFO_ALL);

?>