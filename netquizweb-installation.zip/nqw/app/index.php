<?php

// Redirection à l'URL d'accueil
header('Location: app/questionnaires.php');

?>