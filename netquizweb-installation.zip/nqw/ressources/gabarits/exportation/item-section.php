
		<section>
			<id_section><?php echo $item->getXML("id_item")?></id_section>		
			<titre><?php echo $item->getXML("titre")?></titre>
			<generation_question_type><?php echo $item->getXML("generation_question_type")?></generation_question_type>
			<date_creation><?php echo $item->getXML("date_creation")?></date_creation>
			<date_modification><?php echo $item->getXML("date_modification")?></date_modification>
		</section>
