  <collection>
		<url_domaine><?php echo URL_DOMAINE ?></url_domaine>
		<id_projet><?php echo $collection->getXML("id_projet")?></id_projet>
		<id_collection><?php echo $collection->getXML("id_collection")?></id_collection>
		<titre><?php echo $collection->getXML("titre")?></titre>
		<remarque><?php echo $collection->getXML("remarque")?></remarque>
		<date_creation><?php echo $collection->getXML("date_creation")?></date_creation>
		<date_modification><?php echo $collection->getXML("date_modification")?></date_modification>
  </collection>

