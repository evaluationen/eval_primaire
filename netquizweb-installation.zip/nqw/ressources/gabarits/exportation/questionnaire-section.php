
	  <questionnaire_item>
		<url_domaine><?php echo URL_DOMAINE ?></url_domaine>
		<id_section><?php echo $item->getXML("id_item")?></id_section>
		<id_projet><?php echo $item->getXML("id_projet")?></id_projet>
		<type>section</type>
	  </questionnaire_item>
	