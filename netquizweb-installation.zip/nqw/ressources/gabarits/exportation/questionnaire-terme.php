
		<questionnaire_terme>
			<url_domaine><?php echo URL_DOMAINE ?></url_domaine>
			<id_projet><?php echo $terme->getXML("id_projet")?></id_projet>
			<id_terme><?php echo $terme->getXML("id_terme")?></id_terme>
		</questionnaire_terme>
	