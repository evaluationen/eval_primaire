
		<questionnaire_item>
			<url_domaine><?php echo URL_DOMAINE ?></url_domaine>
			<id_item><?php echo $item->getXML("id_item")?></id_item>
			<id_section><?php echo $item->getXML("id_section")?></id_section>
			<id_projet><?php echo $item->getXML("id_projet")?></id_projet>
			<demarrer_media_quest><?php echo $item->getXML("demarrer_media_quest")?></demarrer_media_quest>
			<ponderation_quest></ponderation_quest>
			<demarrer_media_quest></demarrer_media_quest>
			<afficher_solution_quest></afficher_solution_quest>
			<ordre_presentation_quest></ordre_presentation_quest>
			<type_etiquettes_quest></type_etiquettes_quest>
			<type_bonnesreponses_quest></type_bonnesreponses_quest>
			<points_retranches_quest></points_retranches_quest>
			<majmin_quest></majmin_quest>
			<ponctuation_quest></ponctuation_quest>
			<orientation_elements_quest></orientation_elements_quest>
			<couleur_element_quest></couleur_element_quest>
			<couleur_element_associe_quest></couleur_element_associe_quest>
			<afficher_masque_quest></afficher_masque_quest>
			<type_champs_quest></type_champs_quest>			
			<type>item</type>
		</questionnaire_item>
	