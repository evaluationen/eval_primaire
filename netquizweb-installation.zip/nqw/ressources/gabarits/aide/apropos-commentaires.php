<div class="boxApropos">
	<div class="boxTitre"><p><?php echo TXT_NETQUIZ_WEB ?></p></div>
	<div class="boxContenu">
		<ul>
			<li><a href="#" onclick="javascript:changeFancybox('questionnaires.php?demande=aide_apropos_intro');"><?php echo TXT_INTRODUCTION ?></a></li>
			<li><a href="#" onclick="javascript:changeFancybox('questionnaires.php?demande=aide_apropos_droits');"><?php echo TXT_DROITS_UTILISATION ?></a></li>
			<li><a href="#" onclick="javascript:changeFancybox('questionnaires.php?demande=aide_apropos_generique');"><?php echo TXT_GENERIQUE ?></a></li>
			<li class="actif"><a href="#" onclick="javascript:changeFancybox('questionnaires.php?demande=aide_apropos_commentaires');"><?php echo TXT_COMMENTAIRES ?></a></li>
		</ul>
		
			<h1><?php echo TXT_A_PROPOS ?> <span class="sep">&gt;</span> <?php echo TXT_COMMENTAIRES?> </h1>
            <p><?php echo TXT_APROPOS_COMMENTAIRE_1?></p>
			<p><?php echo TXT_APROPOS_COMMENTAIRE_ALLER_SECTION ?>&nbsp;<a href="#" onClick="window.open('<?php echo TXT_APROPOS_COMMENTAIRE_URL?>')"><?php echo TXT_APROPOS_COMMENTAIRE_COMMENTAIRES?></a>.</p>
						

	</div>
</div>
