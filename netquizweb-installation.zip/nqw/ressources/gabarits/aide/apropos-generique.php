<div class="boxApropos">
	<div class="boxTitre"><p><?php echo TXT_NETQUIZ_WEB ?></p></div>
	<div class="boxContenu">
		<ul>
			<li><a href="#" onclick="javascript:changeFancybox('questionnaires.php?demande=aide_apropos_intro');"><?php echo TXT_INTRODUCTION ?></a></li>
			<li><a href="#" onclick="javascript:changeFancybox('questionnaires.php?demande=aide_apropos_droits');"><?php echo TXT_DROITS_UTILISATION ?></a></li>
			<li class="actif"><a href="#" onclick="javascript:changeFancybox('questionnaires.php?demande=aide_apropos_generique');"><?php echo TXT_GENERIQUE ?></a></li>
			<li><a href="#" onclick="javascript:changeFancybox('questionnaires.php?demande=aide_apropos_commentaires');"><?php echo TXT_COMMENTAIRES ?></a></li>
		</ul>
		
			
		<h1><?php echo TXT_A_PROPOS ?> <span class="sep">&gt;</span> <?php echo TXT_GENERIQUE ?></h1>

		<?php echo TXT_GENERIQUE_LIGNE_1 ?>
		<?php echo TXT_GENERIQUE_LIGNE_2 ?>
		<?php echo TXT_GENERIQUE_LIGNE_3 ?>
		<?php echo TXT_GENERIQUE_LIGNE_4 ?>
		<?php echo TXT_GENERIQUE_LIGNE_5 ?>
		<?php echo TXT_GENERIQUE_LIGNE_6 ?>
		<?php echo TXT_GENERIQUE_LIGNE_7 ?>
		<?php echo TXT_GENERIQUE_LIGNE_8 ?>
		<?php echo TXT_GENERIQUE_LIGNE_9 ?>
		<?php echo TXT_GENERIQUE_LIGNE_10 ?>
		<?php echo TXT_GENERIQUE_LIGNE_11 ?>
		<?php echo TXT_GENERIQUE_LIGNE_12 ?>
				
	</div>
</div>
