<div class="boxApropos">
	<div class="boxTitre"><p><?php echo TXT_NETQUIZ_WEB ?></p></div>
	<div class="boxContenu">
		<ul>
			<li><a href="#" onclick="javascript:changeFancybox('questionnaires.php?demande=aide_apropos_intro');"><?php echo TXT_INTRODUCTION ?></a></li>
			<li class="actif"><a href="#" onclick="javascript:changeFancybox('questionnaires.php?demande=aide_apropos_droits');"><?php echo TXT_DROITS_UTILISATION ?></a></li>
			<li><a href="#" onclick="javascript:changeFancybox('questionnaires.php?demande=aide_apropos_generique');"><?php echo TXT_GENERIQUE ?></a></li>
			<li><a href="#" onclick="javascript:changeFancybox('questionnaires.php?demande=aide_apropos_commentaires');"><?php echo TXT_COMMENTAIRES ?></a></li>
		</ul>
		
			<h1><?php echo TXT_A_PROPOS?> <span class="sep">&gt;</span> <?php echo TXT_DROITS_UTILISATION ?></h1>
        	<div class="scroll">
				<?php echo TXT_DROITS_UTILISATION_NQW ?>               
			</div>
			
	</div>
</div>
