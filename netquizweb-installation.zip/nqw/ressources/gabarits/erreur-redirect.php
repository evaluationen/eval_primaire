

<META HTTP-EQUIV=\"Refresh\" CONTENT=\"0;URL=<?php echo $url_redirect ?>\">
<script>document.location='<?php echo $url_redirect ?>'</script>

