<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title><?php echo TXT_NETQUIZ_WEB?> - <?php echo TXT_ITEMS ?></title>
	<script type="text/javascript">

		// Fermer la fenêtre et rafraichir la page parent
		parent.fermerSelectionItems('<?php echo $idItemDest ?>');
		
	</script>
	
</head>

<body>
						
</body>
</html>

