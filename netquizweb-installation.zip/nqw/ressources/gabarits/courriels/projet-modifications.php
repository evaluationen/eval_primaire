<?php echo TXT_COURRIEL_PROJET_MODIFICATIONS_BONJOUR . " " . $element->get("prenom") . " " . $element->get("nom") ?>,

<?php echo TXT_COURRIEL_PROJET_MODIFICATIONS_LIGNE1A . " " . URL_DOMAINE . URL_BASE . TXT_COURRIEL_PROJET_MODIFICATIONS_LIGNE1B . $element->get("titre") . TXT_COURRIEL_PROJET_MODIFICATIONS_LIGNE1C ?>


<?php echo $element->get("modifications")?>

<?php echo TXT_COURRIEL_PROJET_MODIFICATIONS_MERCI ?>


<?php echo TXT_COURRIEL_PROJET_MODIFICATIONS_SIGNATURE ?>

