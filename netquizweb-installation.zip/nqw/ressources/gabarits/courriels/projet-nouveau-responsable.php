<?php echo TXT_COURRIEL_NOUVEAU_RESPONSABLE_BONJOUR . " " . $element->get("prenom") . " " . $element->get("nom") ?>,

<?php echo $element->get("responsable_invitation") . " " . TXT_COURRIEL_NOUVEAU_RESPONSABLE_LIGNE1A . $element->get("titre") . TXT_COURRIEL_NOUVEAU_RESPONSABLE_LIGNE1B ?>


<?php echo TXT_COURRIEL_NOUVEAU_RESPONSABLE_LIGNE2 ?>


<?php echo URL_DOMAINE . URL_BASE ?> 

<?php echo TXT_COURRIEL_NOUVEAU_RESPONSABLE_MERCI ?>


<?php echo TXT_COURRIEL_NOUVEAU_RESPONSABLE_SIGNATURE ?>

