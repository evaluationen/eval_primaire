<?php echo TXT_COURRIEL_COLLABORATEUR_RETRAIT_BONJOUR . " " . $element->get("prenom") . " " . $element->get("nom") ?>,

<?php echo TXT_COURRIEL_COLLABORATEUR_RETRAIT_LIGNE1A . " " . $element->get("titre") . " " . TXT_COURRIEL_COLLABORATEUR_RETRAIT_LIGNE1B . " " . $element->get("responsable_invitation") ?>.

<?php echo TXT_COURRIEL_COLLABORATEUR_RETRAIT_LIGNE2 ?> 


<?php echo TXT_COURRIEL_COLLABORATEUR_RETRAIT_MERCI ?>


<?php echo TXT_COURRIEL_COLLABORATEUR_RETRAIT_SIGNATURE ?>

