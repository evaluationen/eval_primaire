<?php echo TXT_COURRIEL_APPROBATION_BONJOUR ?>,

<?php echo TXT_DEMANDE_ACTIVATION_COMPTE_TEXTE ?> 

<?php echo URL_DOMAINE . URL_BASE ?>app/admin.php?demande=approbation


<?php echo TXT_COURRIEL_APPROBATION_MERCI ?>

