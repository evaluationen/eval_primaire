<?php echo TXT_COURRIEL_APPROBATION_BONJOUR ?> <?php echo html_entity_decode($element->get("prenom"),ENT_QUOTES, "UTF-8") . " " . html_entity_decode($element->get("nom"),ENT_QUOTES, "UTF-8")?>,

<?php echo TXT_COURRIEL_APPROBATION_LIGNE1 ?> 

<?php echo URL_DOMAINE . URL_BASE ?>


<?php echo TXT_COURRIEL_APPROBATION_LIGNE2 ?>


<?php echo TXT_COURRIEL_APPROBATION_MERCI ?>

