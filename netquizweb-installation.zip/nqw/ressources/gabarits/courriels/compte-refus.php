<?php echo TXT_COURRIEL_APPROBATION_BONJOUR ?> <?php echo html_entity_decode($element->get("prenom"),ENT_QUOTES, "UTF-8") . " " . html_entity_decode($element->get("nom"),ENT_QUOTES, "UTF-8")?>,

<?php echo TXT_COURRIEL_REFUS_LIGNE1 ?>


<?php echo TXT_COURRIEL_REFUS_LIGNE2 ?>
 
