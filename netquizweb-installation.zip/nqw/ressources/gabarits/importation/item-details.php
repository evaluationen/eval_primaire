
				<h3><?php echo TXT_ITEM . " " . TXT_POSITION . " " . $item->get("idx_item") . " (" . TXT_ID_ITEM . "=" . $item->get("id_item") . ")"?></h3>
				
				<ul>
					<?php echo $item->get("messages") ?>
				</ul>
				
				
