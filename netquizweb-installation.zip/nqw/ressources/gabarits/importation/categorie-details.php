
				<h3><?php echo TXT_CATEGORIE . " " . TXT_POSITION . " " . $categorie->get("idx_categorie") . " (" . TXT_ID_CATEGORIE . "=" . $categorie->get("id_categorie") . ")"?></h3>
				
				<ul>
					<?php echo $categorie->get("messages") ?>
				</ul>
				