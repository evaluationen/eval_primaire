
				<h3><?php echo TXT_QUESTIONNAIRE . " " . TXT_POSITION . " " . $quest->get("idx_questionnaire") . " (" . TXT_ID_QUEST . "=" . $quest->get("id_questionnaire") . ")"?></h3>
				
				<ul>
					<?php echo $quest->get("messages") ?>
				</ul>
				
				
