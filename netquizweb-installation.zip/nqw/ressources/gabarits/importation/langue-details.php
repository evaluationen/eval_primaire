
				<h3><?php echo TXT_LANGUE . " " . TXT_POSITION . " " . $langue->get("idx_langue") . " (" . TXT_ID_LANGUE . "=" . $langue->get("id_langue") . ")"?></h3>
				
				<ul>
					<?php echo $langue->get("messages") ?>
				</ul>
				