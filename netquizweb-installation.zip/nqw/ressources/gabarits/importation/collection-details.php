
				<h3><?php echo TXT_COLLECTION . " " . TXT_POSITION . " " . $collection->get("idx_collection") . " (" . TXT_ID_COLLECTION . "=" . $collection->get("id_collection") . ")"?></h3>
				
				<ul>
					<?php echo $collection->get("messages") ?>
				</ul>
				