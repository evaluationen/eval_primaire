
				<h3><?php echo TXT_ITEM . " " . TXT_POSITION . " " . $media->get("idx_media") . " (" . TXT_ID_MEDIA . "=" . $media->get("id_media") . ")"?></h3>
				
				<ul>
					<?php echo $media->get("messages") ?>
				</ul>
				
				
