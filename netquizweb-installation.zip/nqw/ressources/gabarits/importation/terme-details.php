
				<h3><?php echo TXT_TERME . " " . TXT_POSITION . " " . $terme->get("idx_terme") . " (" . TXT_ID_TERME . "=" . $terme->get("id_terme") . ")"?></h3>
				
				<ul>
					<?php echo $terme->get("messages") ?>
				</ul>
				