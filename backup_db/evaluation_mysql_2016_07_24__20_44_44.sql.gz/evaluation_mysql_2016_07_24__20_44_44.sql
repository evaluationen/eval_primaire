-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: evaluation
-- ------------------------------------------------------
-- Server version	5.6.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `eval_answers`
--

DROP TABLE IF EXISTS `eval_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eval_answers` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL,
  `q_option` text NOT NULL,
  `ssid` int(11) NOT NULL,
  `score_u` float NOT NULL DEFAULT '0',
  `rid` int(11) NOT NULL,
  PRIMARY KEY (`aid`),
  KEY `FK_eval_answers` (`ssid`),
  KEY `FK_eval_answers_qbank` (`qid`),
  CONSTRAINT `FK_eval_answers` FOREIGN KEY (`ssid`) REFERENCES `eval_student_sch` (`ssid`),
  CONSTRAINT `FK_eval_answers_qbank` FOREIGN KEY (`qid`) REFERENCES `eval_qbank` (`qid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eval_answers`
--

LOCK TABLES `eval_answers` WRITE;
/*!40000 ALTER TABLE `eval_answers` DISABLE KEYS */;
/*!40000 ALTER TABLE `eval_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eval_category`
--

DROP TABLE IF EXISTS `eval_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eval_category` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(1000) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eval_category`
--

LOCK TABLES `eval_category` WRITE;
/*!40000 ALTER TABLE `eval_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `eval_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eval_circo`
--

DROP TABLE IF EXISTS `eval_circo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eval_circo` (
  `ciid` int(11) NOT NULL AUTO_INCREMENT,
  `rne` char(8) NOT NULL,
  `label` varchar(225) DEFAULT NULL,
  UNIQUE KEY `rnid` (`ciid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eval_circo`
--

LOCK TABLES `eval_circo` WRITE;
/*!40000 ALTER TABLE `eval_circo` DISABLE KEYS */;
INSERT INTO `eval_circo` VALUES (1,'9760304B','CIRCONSCRIPTION 1ER DEGRE IEN ASH 1ER-2ND DEGRE+PPF+FORMATION\r'),(2,'9760297U','CIRCONSCRIPTION 1ER DEGRE IEN BANDRABOUA (MAYOTTE NORD)\r'),(3,'9760233Z','CIRCONSCRIPTION 1ER DEGRE IEN DEMBENI (MAYOTTE SUD)\r'),(4,'9760232Y','CIRCONSCRIPTION 1ER DEGRE IEN IENA KOUNGOU\r'),(5,'9760352D','CIRCONSCRIPTION 1ER DEGRE IEN MAMOUDZOU CENTRE\r'),(6,'9760263G','CIRCONSCRIPTION 1ER DEGRE IEN MAMOUDZOU NORD\r'),(7,'9760299W','CIRCONSCRIPTION 1ER DEGRE IEN MAMOUDZOU SUD\r'),(8,'9760285F','CIRCONSCRIPTION 1ER DEGRE IEN PETITE-TERRE\r'),(9,'9760234A','CIRCONSCRIPTION 1ER DEGRE IEN SADA (MAYOTTE OUEST)\r'),(10,'9760309G','CIRCONSCRIPTION 1ER DEGRE IEN TSINGONI');
/*!40000 ALTER TABLE `eval_circo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eval_class`
--

DROP TABLE IF EXISTS `eval_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eval_class` (
  `clid` int(11) NOT NULL AUTO_INCREMENT,
  `code` char(3) NOT NULL,
  `class_name` varchar(50) NOT NULL,
  `cyid` int(11) NOT NULL,
  UNIQUE KEY `clid` (`clid`),
  KEY `FK_eval_class` (`cyid`),
  CONSTRAINT `FK_eval_class` FOREIGN KEY (`cyid`) REFERENCES `eval_cycle` (`cyid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eval_class`
--

LOCK TABLES `eval_class` WRITE;
/*!40000 ALTER TABLE `eval_class` DISABLE KEYS */;
INSERT INTO `eval_class` VALUES (1,'PS','Petite section de maternelle',1),(2,'MS','Moyenne section de maternelle',1),(3,'GS','Grande section de maternelle',1),(4,'CP','Cours préparatoire',2),(5,'CE1','Cours élémentaire 1re année',2),(6,'CE2','Cours élémentaire 2e année',3),(7,'CM1','Cours moyen niveau 1',3),(8,'CM2','Cours moyen niveau 2',3);
/*!40000 ALTER TABLE `eval_class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eval_coef`
--

DROP TABLE IF EXISTS `eval_coef`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eval_coef` (
  `coid` int(11) NOT NULL AUTO_INCREMENT,
  `quid` int(11) NOT NULL,
  `qid` int(11) NOT NULL,
  `coef` float NOT NULL,
  PRIMARY KEY (`coid`),
  KEY `FK_eval_coef` (`qid`),
  KEY `FK_eval_coef_quiz` (`quid`),
  CONSTRAINT `FK_eval_coef` FOREIGN KEY (`qid`) REFERENCES `eval_qbank` (`qid`),
  CONSTRAINT `FK_eval_coef_quiz` FOREIGN KEY (`quid`) REFERENCES `eval_quiz` (`quid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eval_coef`
--

LOCK TABLES `eval_coef` WRITE;
/*!40000 ALTER TABLE `eval_coef` DISABLE KEYS */;
/*!40000 ALTER TABLE `eval_coef` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eval_competency`
--

DROP TABLE IF EXISTS `eval_competency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eval_competency` (
  `comid` int(11) NOT NULL AUTO_INCREMENT,
  `compet_name` varchar(250) NOT NULL,
  `description` text,
  `clids` text,
  `quids` text,
  UNIQUE KEY `comid` (`comid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eval_competency`
--

LOCK TABLES `eval_competency` WRITE;
/*!40000 ALTER TABLE `eval_competency` DISABLE KEYS */;
/*!40000 ALTER TABLE `eval_competency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eval_cycle`
--

DROP TABLE IF EXISTS `eval_cycle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eval_cycle` (
  `cyid` int(11) NOT NULL AUTO_INCREMENT,
  `cycle_name` varchar(50) NOT NULL,
  UNIQUE KEY `cyid` (`cyid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eval_cycle`
--

LOCK TABLES `eval_cycle` WRITE;
/*!40000 ALTER TABLE `eval_cycle` DISABLE KEYS */;
INSERT INTO `eval_cycle` VALUES (1,'Cycle 1'),(2,'Cycle 2'),(3,'Cycle 3');
/*!40000 ALTER TABLE `eval_cycle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eval_etab`
--

DROP TABLE IF EXISTS `eval_etab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eval_etab` (
  `eid` int(11) NOT NULL AUTO_INCREMENT,
  `rne` char(8) NOT NULL,
  `label` varchar(225) NOT NULL,
  `ciid` int(11) DEFAULT NULL,
  UNIQUE KEY `eid` (`eid`),
  KEY `FK_eval_etab` (`label`),
  KEY `FK_eval_etab_school` (`rne`),
  KEY `FK_eval_etab_circo` (`ciid`),
  CONSTRAINT `FK_eval_etab_circo` FOREIGN KEY (`ciid`) REFERENCES `eval_circo` (`ciid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eval_etab`
--

LOCK TABLES `eval_etab` WRITE;
/*!40000 ALTER TABLE `eval_etab` DISABLE KEYS */;
INSERT INTO `eval_etab` VALUES (1,'9760022V','ECOLE ELEMENTAIRE DE LABATTOIR 1 LA FERME',8),(2,'9760056G','ECOLE ELEMENTAIRE DE LABATTOIR 2 POTELEA',8),(3,'9760093X','ECOLE ELEMENTAIRE DE LABATTOIR 3 BADAMIERS',8),(4,'9760024X','ECOLE ELEMENTAIRE DE LABATTOIR 4 MORIOMBENI',8),(5,'9760139X','ECOLE ELEMENTAIRE DE LABATTOIR 5 MOYA',8),(6,'9760186Y','ECOLE ELEMENTAIRE DE LABATTOIR 6 FOUR A CHAUX',8),(7,'9760260D','ECOLE ELEMENTAIRE DE LABATTOIR 7 TOUTOUROUCHA',8);
/*!40000 ALTER TABLE `eval_etab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eval_group`
--

DROP TABLE IF EXISTS `eval_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eval_group` (
  `gid` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(125) DEFAULT NULL,
  `vadidate_for_days` int(15) DEFAULT NULL,
  UNIQUE KEY `gid` (`gid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eval_group`
--

LOCK TABLES `eval_group` WRITE;
/*!40000 ALTER TABLE `eval_group` DISABLE KEYS */;
INSERT INTO `eval_group` VALUES (1,'gestionaire',0);
/*!40000 ALTER TABLE `eval_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eval_level`
--

DROP TABLE IF EXISTS `eval_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eval_level` (
  `lid` int(11) NOT NULL AUTO_INCREMENT,
  `level_name` varchar(1000) NOT NULL,
  PRIMARY KEY (`lid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eval_level`
--

LOCK TABLES `eval_level` WRITE;
/*!40000 ALTER TABLE `eval_level` DISABLE KEYS */;
/*!40000 ALTER TABLE `eval_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eval_options`
--

DROP TABLE IF EXISTS `eval_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eval_options` (
  `oid` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL,
  `q_option` text NOT NULL,
  `q_option_match` varchar(1000) DEFAULT NULL,
  `score` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`oid`),
  KEY `FK_eval_options` (`qid`),
  CONSTRAINT `FK_eval_options` FOREIGN KEY (`qid`) REFERENCES `eval_qbank` (`qid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eval_options`
--

LOCK TABLES `eval_options` WRITE;
/*!40000 ALTER TABLE `eval_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `eval_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eval_qbank`
--

DROP TABLE IF EXISTS `eval_qbank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eval_qbank` (
  `qid` int(11) NOT NULL AUTO_INCREMENT,
  `question_type` varchar(100) NOT NULL DEFAULT 'Multiple Choice Single Answer',
  `question` text NOT NULL,
  `description` text NOT NULL,
  `is_default_txt` tinyint(4) NOT NULL,
  `default_txt` mediumtext NOT NULL,
  `lid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `no_time_served` int(11) NOT NULL DEFAULT '0',
  `no_time_corrected` int(11) NOT NULL DEFAULT '0',
  `no_time_incorrected` int(11) NOT NULL DEFAULT '0',
  `no_time_unattempted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`qid`),
  KEY `FK_eval_qbank_categ` (`cid`),
  KEY `FK_eval_qbank_level` (`lid`),
  CONSTRAINT `FK_eval_qbank_categ` FOREIGN KEY (`cid`) REFERENCES `eval_category` (`cid`),
  CONSTRAINT `FK_eval_qbank_level` FOREIGN KEY (`lid`) REFERENCES `eval_level` (`lid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eval_qbank`
--

LOCK TABLES `eval_qbank` WRITE;
/*!40000 ALTER TABLE `eval_qbank` DISABLE KEYS */;
/*!40000 ALTER TABLE `eval_qbank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eval_qcl`
--

DROP TABLE IF EXISTS `eval_qcl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eval_qcl` (
  `qcl_id` int(11) NOT NULL AUTO_INCREMENT,
  `quid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `lid` int(11) NOT NULL,
  `noq` int(11) NOT NULL,
  PRIMARY KEY (`qcl_id`),
  KEY `FK_eval_qcl` (`quid`),
  KEY `FK_eval_qcl_categ` (`cid`),
  KEY `FK_eval_qcl_level` (`lid`),
  CONSTRAINT `FK_eval_qcl` FOREIGN KEY (`quid`) REFERENCES `eval_quiz` (`quid`),
  CONSTRAINT `FK_eval_qcl_categ` FOREIGN KEY (`cid`) REFERENCES `eval_category` (`cid`),
  CONSTRAINT `FK_eval_qcl_level` FOREIGN KEY (`lid`) REFERENCES `eval_level` (`lid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eval_qcl`
--

LOCK TABLES `eval_qcl` WRITE;
/*!40000 ALTER TABLE `eval_qcl` DISABLE KEYS */;
/*!40000 ALTER TABLE `eval_qcl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eval_quiz`
--

DROP TABLE IF EXISTS `eval_quiz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eval_quiz` (
  `quid` int(11) NOT NULL AUTO_INCREMENT,
  `quiz_name` varchar(1000) NOT NULL,
  `description` text NOT NULL,
  `start_date` int(11) NOT NULL,
  `end_date` int(11) NOT NULL,
  `qids` text NOT NULL,
  `noq` int(11) NOT NULL,
  `correct_score` float NOT NULL,
  `incorrect_score` float NOT NULL,
  `ip_address` text NOT NULL,
  `duration` int(11) NOT NULL DEFAULT '10',
  `maximum_attempts` int(11) NOT NULL DEFAULT '1',
  `pass_percentage` float NOT NULL DEFAULT '50',
  `view_answer` int(11) NOT NULL DEFAULT '1',
  `camera_req` int(11) NOT NULL DEFAULT '1',
  `question_selection` int(11) NOT NULL DEFAULT '1',
  `gen_certificate` int(11) NOT NULL DEFAULT '0',
  `certificate_text` text,
  PRIMARY KEY (`quid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eval_quiz`
--

LOCK TABLES `eval_quiz` WRITE;
/*!40000 ALTER TABLE `eval_quiz` DISABLE KEYS */;
/*!40000 ALTER TABLE `eval_quiz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eval_result`
--

DROP TABLE IF EXISTS `eval_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eval_result` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `quid` int(11) NOT NULL,
  `comid` int(11) NOT NULL,
  `ssid` int(11) NOT NULL,
  `result_status` varchar(100) NOT NULL DEFAULT 'Open',
  `start_time` int(11) NOT NULL,
  `end_time` int(11) NOT NULL,
  `categories` text NOT NULL,
  `category_range` text NOT NULL,
  `r_qids` text NOT NULL,
  `individual_time` text NOT NULL,
  `total_time` int(11) NOT NULL DEFAULT '0',
  `score_obtained` float NOT NULL DEFAULT '0',
  `percentage_obtained` float NOT NULL DEFAULT '0',
  `attempted_ip` varchar(100) NOT NULL,
  `score_individual` text NOT NULL,
  `photo` varchar(100) NOT NULL,
  `manual_valuation` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`rid`),
  KEY `FK_eval_result` (`ssid`),
  KEY `FK_eval_result_competences` (`comid`),
  CONSTRAINT `FK_eval_result` FOREIGN KEY (`ssid`) REFERENCES `eval_student_sch` (`ssid`),
  CONSTRAINT `FK_eval_result_competences` FOREIGN KEY (`comid`) REFERENCES `eval_competency` (`comid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eval_result`
--

LOCK TABLES `eval_result` WRITE;
/*!40000 ALTER TABLE `eval_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `eval_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eval_school_year`
--

DROP TABLE IF EXISTS `eval_school_year`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eval_school_year` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `start_year` date NOT NULL,
  `end_year` date NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  UNIQUE KEY `sid` (`sid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eval_school_year`
--

LOCK TABLES `eval_school_year` WRITE;
/*!40000 ALTER TABLE `eval_school_year` DISABLE KEYS */;
INSERT INTO `eval_school_year` VALUES (1,'2016-08-24','2017-07-07',1);
/*!40000 ALTER TABLE `eval_school_year` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eval_student_sch`
--

DROP TABLE IF EXISTS `eval_student_sch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eval_student_sch` (
  `ssid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `add_uid` int(11) NOT NULL,
  `edit_uid` int(11) NOT NULL,
  `eid` int(11) NOT NULL,
  `clid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `date_add` datetime DEFAULT NULL,
  `date_upd` datetime DEFAULT NULL,
  UNIQUE KEY `ssid` (`ssid`),
  KEY `FK_eval_student_sch_cl` (`clid`),
  KEY `FK_eval_student_sch_user` (`uid`),
  KEY `FK_eval_student_sch_user_add` (`add_uid`),
  KEY `FK_eval_student_sch_edit_user` (`edit_uid`),
  KEY `FK_eval_student_sch_etab` (`eid`),
  KEY `FK_eval_student_sch_school_year` (`sid`),
  CONSTRAINT `FK_eval_student_sch_cl` FOREIGN KEY (`clid`) REFERENCES `eval_class` (`clid`),
  CONSTRAINT `FK_eval_student_sch_edit_user` FOREIGN KEY (`edit_uid`) REFERENCES `eval_users` (`uid`),
  CONSTRAINT `FK_eval_student_sch_etab` FOREIGN KEY (`eid`) REFERENCES `eval_etab` (`eid`),
  CONSTRAINT `FK_eval_student_sch_school_year` FOREIGN KEY (`sid`) REFERENCES `eval_school_year` (`sid`),
  CONSTRAINT `FK_eval_student_sch_user` FOREIGN KEY (`uid`) REFERENCES `eval_users` (`uid`),
  CONSTRAINT `FK_eval_student_sch_user_add` FOREIGN KEY (`add_uid`) REFERENCES `eval_users` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eval_student_sch`
--

LOCK TABLES `eval_student_sch` WRITE;
/*!40000 ALTER TABLE `eval_student_sch` DISABLE KEYS */;
/*!40000 ALTER TABLE `eval_student_sch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eval_users`
--

DROP TABLE IF EXISTS `eval_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eval_users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(100) NOT NULL,
  `password` varchar(1000) NOT NULL,
  `email` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `birth` date NOT NULL,
  `gid` int(11) NOT NULL,
  `contact_no` varchar(1000) NOT NULL,
  `su` int(11) NOT NULL DEFAULT '0',
  `subscription_expired` int(11) NOT NULL DEFAULT '0',
  `verify_code` int(11) NOT NULL DEFAULT '0',
  `qrcode` varchar(255) DEFAULT NULL,
  `admin_id` int(11) NOT NULL,
  `etab_org` int(11) NOT NULL,
  `date_insert` datetime NOT NULL,
  `date_upd` datetime NOT NULL,
  PRIMARY KEY (`uid`),
  KEY `FK_eval_users_etab_origine` (`etab_org`),
  CONSTRAINT `FK_eval_users_etab_origine` FOREIGN KEY (`etab_org`) REFERENCES `eval_etab` (`eid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eval_users`
--

LOCK TABLES `eval_users` WRITE;
/*!40000 ALTER TABLE `eval_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `eval_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-24 20:44:50
